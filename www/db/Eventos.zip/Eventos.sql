-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         8.0.30 - MySQL Community Server - GPL
-- SO del servidor:              Win64
-- HeidiSQL Versión:             12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Volcando estructura de base de datos para eventos
CREATE DATABASE IF NOT EXISTS `eventos` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `eventos`;

-- Volcando estructura para tabla eventos.actos
CREATE TABLE IF NOT EXISTS `actos` (
  `Id_acto` int NOT NULL AUTO_INCREMENT,
  `Fecha` date NOT NULL,
  `Hora` time NOT NULL,
  `Titulo` varchar(100) NOT NULL,
  `Descripcion_corta` varchar(2000) NOT NULL,
  `Descripcion_larga` varchar(2500) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT '',
  `Num_asistentes` int NOT NULL,
  `Id_tipo_acto` int NOT NULL,
  `id_ponente` int NOT NULL,
  PRIMARY KEY (`Id_acto`),
  KEY `FK_Actos_Id_Tipo_Acto` (`Id_tipo_acto`),
  KEY `FK_Actos_id_ponente` (`id_ponente`) USING BTREE,
  CONSTRAINT `FK_Actos_id_ponente` FOREIGN KEY (`id_ponente`) REFERENCES `lista_ponentes` (`id_ponente`),
  CONSTRAINT `FK_Actos_Id_Tipo_Acto` FOREIGN KEY (`Id_tipo_acto`) REFERENCES `tipo_acto` (`Id_tipo_acto`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb3;

-- Volcando datos para la tabla eventos.actos: ~23 rows (aproximadamente)
INSERT INTO `actos` (`Id_acto`, `Fecha`, `Hora`, `Titulo`, `Descripcion_corta`, `Descripcion_larga`, `Num_asistentes`, `Id_tipo_acto`, `id_ponente`) VALUES
	(5, '2023-05-18', '12:00:00', 'Charla sobre Salud - Psicologia', 'Discusión sobre nutrición y bienestar', 'Expertos en salud hablarán sobre la importancia de una nutrición adecuada.', 80, 5, 4),
	(6, '2023-06-07', '15:00:00', 'Festival de Música', 'Festival con bandas locales', 'Disfruta de la mejor música en vivo de bandas locales.', 200, 1, 1),
	(7, '2023-07-19', '08:30:00', 'Conferencia de Educación', 'Nuevas tendencias en educación', 'Explorando innovaciones y tendencias actuales en el ámbito educativo.', 150, 2, 1),
	(8, '2023-08-03', '13:45:00', 'Taller de Jardinería', 'Aprende sobre jardinería urbana', 'Un taller práctico para iniciar tu propio jardín urbano.', 40, 3, 1),
	(9, '2023-09-12', '17:00:00', 'Expo Tecnológica', 'Exhibición de tecnología emergente', 'Las últimas innovaciones en tecnología y electrónica.', 90, 4, 1),
	(10, '2023-10-26', '12:00:00', 'Evento de Networking', 'Encuentro de profesionales', 'Una gran oportunidad para hacer networking con profesionales de distintos sectores.', 110, 5, 1),
	(11, '2023-11-05', '09:30:00', 'Carrera Benéfica', 'Evento deportivo por una causa', 'Participa en una carrera para recaudar fondos para una causa benéfica.', 160, 1, 1),
	(12, '2023-12-17', '14:00:00', 'Gala de Navidad', 'Celebración anual navideña', 'Únete a nuestra gala anual para celebrar la temporada navideña.', 180, 2, 1),
	(13, '2023-01-28', '10:15:00', 'Taller de Fotografía', 'Aprende técnicas de fotografía', 'Un taller para aficionados y profesionales de la fotografía.', 55, 3, 1),
	(14, '2023-02-09', '16:30:00', 'Simposio de Ciencia', 'Encuentro científico', 'Discusiones y presentaciones sobre los últimos avances en diversas áreas de la ciencia.', 95, 4, 1),
	(15, '2023-03-15', '08:00:00', 'Desayuno Empresarial', 'Networking y charlas de negocios', 'Un evento matutino para empresarios y emprendedores.', 130, 5, 1),
	(16, '2023-04-05', '18:00:00', 'Noche de Cine', 'Proyección de películas independientes', 'Disfruta de una selección de películas independientes.', 65, 1, 1),
	(17, '2023-05-23', '13:00:00', 'Charla sobre Sostenibilidad', 'Sostenibilidad y medio ambiente', 'Discusión sobre prácticas sostenibles y su impacto en el medio ambiente.', 75, 2, 1),
	(18, '2023-06-16', '17:15:00', 'Fiesta de Verano', 'Celebración al aire libre', 'Celebra el inicio del verano con música, comida y diversión.', 190, 3, 1),
	(19, '2023-07-30', '19:00:00', 'Observación de Estrellas', 'Noche de astronomía', 'Una noche dedicada a la observación de las estrellas y constelaciones.', 60, 4, 1),
	(20, '2023-12-04', '12:00:00', 'Acto de prueba 1', 'Descripción corta del Acto de prueba 1', 'Descripción larga del Acto de prueba 1', 15, 2, 1),
	(21, '2023-12-05', '12:00:00', 'Acto de prueba 2', 'Descripción corta del Acto de prueba 2', 'Descripción larga del Acto de prueba 2', 10, 2, 1),
	(22, '2023-12-06', '12:00:00', 'Acto de prueba 3', 'Descripción corta del Acto de prueba 3', 'Prueba descripcion larga prueba descripcion larga', 10, 1, 1),
	(24, '2023-12-12', '10:00:00', 'Probando ponentes', 'Descripción corta probando ponentes', 'Descripción larga probando ponentes', 15, 2, 2),
	(26, '2020-11-12', '12:00:00', 'paca', 'pacaaaa QA', 'pacaaaa QA', 2, 1, 2);

-- Volcando estructura para tabla eventos.documentacion
CREATE TABLE IF NOT EXISTS `documentacion` (
  `Id_presentacion` int NOT NULL AUTO_INCREMENT,
  `Id_acto` int NOT NULL,
  `Localizacion_documentacion` varchar(100) NOT NULL,
  `Orden` int NOT NULL,
  `Id_persona` int NOT NULL,
  `Titulo_documento` varchar(100) NOT NULL,
  PRIMARY KEY (`Id_presentacion`),
  KEY `FK_Documentacion_Id_Acto` (`Id_acto`),
  KEY `FK_Documentacion_Id_Persona` (`Id_persona`),
  CONSTRAINT `FK_Documentacion_Id_Acto` FOREIGN KEY (`Id_acto`) REFERENCES `actos` (`Id_acto`),
  CONSTRAINT `FK_Documentacion_Id_Persona` FOREIGN KEY (`Id_persona`) REFERENCES `personas` (`Id_persona`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;

-- Volcando datos para la tabla eventos.documentacion: ~4 rows (aproximadamente)

-- Volcando estructura para tabla eventos.inscritos
CREATE TABLE IF NOT EXISTS `inscritos` (
  `Id_inscripcion` int NOT NULL AUTO_INCREMENT,
  `Id_persona` int NOT NULL,
  `id_acto` int NOT NULL,
  `Fecha_inscripcion` datetime NOT NULL,
  PRIMARY KEY (`Id_inscripcion`),
  KEY `FK_Inscritos_Id_Persona` (`Id_persona`),
  KEY `FK_Inscritos_Id_Acto` (`id_acto`),
  CONSTRAINT `FK_Inscritos_Id_Acto` FOREIGN KEY (`id_acto`) REFERENCES `actos` (`Id_acto`),
  CONSTRAINT `FK_Inscritos_Id_Persona` FOREIGN KEY (`Id_persona`) REFERENCES `personas` (`Id_persona`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb3;

-- Volcando datos para la tabla eventos.inscritos: ~16 rows (aproximadamente)
INSERT INTO `inscritos` (`Id_inscripcion`, `Id_persona`, `id_acto`, `Fecha_inscripcion`) VALUES
	(5, 24, 6, '2023-03-22 00:00:00'),
	(12, 24, 9, '2023-10-11 00:00:00'),
	(14, 24, 11, '2023-01-07 00:00:00'),
	(15, 24, 10, '2023-06-01 00:00:00'),
	(16, 24, 18, '2023-03-15 00:00:00'),
	(17, 24, 13, '2023-07-28 00:00:00'),
	(18, 24, 17, '2023-02-08 00:00:00'),
	(19, 24, 14, '2023-09-30 00:00:00'),
	(20, 24, 16, '2023-04-25 00:00:00'),
	(27, 2, 12, '2023-12-06 21:00:25');

-- Volcando estructura para tabla eventos.lista_ponentes
CREATE TABLE IF NOT EXISTS `lista_ponentes` (
  `id_ponente` int NOT NULL AUTO_INCREMENT,
  `Id_persona` int NOT NULL,
  `Id_acto` int NOT NULL,
  `Orden` int NOT NULL,
  PRIMARY KEY (`id_ponente`),
  KEY `FK_Lista_Ponentes_Id_Persona` (`Id_persona`),
  KEY `FK_Lista_Ponentes_Id_Acto` (`Id_acto`),
  CONSTRAINT `FK_Lista_Ponentes_Id_Acto` FOREIGN KEY (`Id_acto`) REFERENCES `actos` (`Id_acto`),
  CONSTRAINT `FK_Lista_Ponentes_Id_Persona` FOREIGN KEY (`Id_persona`) REFERENCES `personas` (`Id_persona`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3;

-- Volcando datos para la tabla eventos.lista_ponentes: ~7 rows (aproximadamente)
INSERT INTO `lista_ponentes` (`id_ponente`, `Id_persona`, `Id_acto`, `Orden`) VALUES
	(4, 24, 12, 4),
	(5, 24, 7, 3),
	(6, 24, 15, 2);

-- Volcando estructura para tabla eventos.personas
CREATE TABLE IF NOT EXISTS `personas` (
  `Id_persona` int NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(50) NOT NULL,
  `Apellido1` varchar(50) NOT NULL,
  `Apellido2` varchar(50) NOT NULL,
  PRIMARY KEY (`Id_persona`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb3;

-- Volcando datos para la tabla eventos.personas: ~20 rows (aproximadamente)
INSERT INTO `personas` (`Id_persona`, `Nombre`, `Apellido1`, `Apellido2`) VALUES
	(1, 'Test', 'Test', 'Test'),
	(2, 'Juan', 'Perez', 'Gomez'),
	(3, 'Maria', 'Lopez', 'Rodriguez'),
	(4, 'Pedro', 'Gonzalez', 'Sanchez'),
	(5, 'Angel', 'Castro', 'Merino'),
	(21, 'Angel', 'Castro', 'Merino'),
	(22, 'Angel', 'Castro', 'Merino'),
	(23, 'Angel', 'Castro', 'Merino'),
	(24, 'Pepito', 'De Los', 'Palotes'),
	(25, 'Paquito', 'diaz', 'diaz'),
	(26, 'Paquito', 'diaz', 'diaz'),
	(27, 'prueba55', 'prueba55', 'prueba55'),
	(28, 'Pepe', 'Martinez', 'Martinez'),
	(29, 'Prueba 1', 'Apellido1', 'Apellido2'),
	(30, 'admin', 'admin', 'admin'),
	(31, 'lucia', 'hidalgo', 'lucia'),
	(32, 'Prueba4', 'Prueba4', 'Prueba4'),
	(34, 'prueba5', 'prueba5', 'prueba5'),
	(36, 'prueba6', 'prueba6', 'prueba6'),
	(38, 'admin', 'admin', 'admin'),
	(39, 'lucia', 'lucia', 'lucia'),
	(40, 'paca', 'paca', 'paca'),
	(41, 'pruebas1', 'pruebas1', 'pruebas1');

-- Volcando estructura para tabla eventos.tipos_usuarios
CREATE TABLE IF NOT EXISTS `tipos_usuarios` (
  `Id_tipo_usuario` int NOT NULL AUTO_INCREMENT,
  `Descripcion` varchar(100) NOT NULL,
  PRIMARY KEY (`Id_tipo_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;

-- Volcando datos para la tabla eventos.tipos_usuarios: ~3 rows (aproximadamente)
INSERT INTO `tipos_usuarios` (`Id_tipo_usuario`, `Descripcion`) VALUES
	(1, 'Ponentes'),
	(2, 'Administrador'),
	(3, 'Usuario normal');

-- Volcando estructura para tabla eventos.tipo_acto
CREATE TABLE IF NOT EXISTS `tipo_acto` (
  `Id_tipo_acto` int NOT NULL AUTO_INCREMENT,
  `Descripcion` varchar(100) NOT NULL,
  PRIMARY KEY (`Id_tipo_acto`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;

-- Volcando datos para la tabla eventos.tipo_acto: ~5 rows (aproximadamente)
INSERT INTO `tipo_acto` (`Id_tipo_acto`, `Descripcion`) VALUES
	(1, 'Musical'),
	(2, 'Gastronómico'),
	(3, 'Cine'),
	(4, 'Teatro'),
	(5, 'Moda');

-- Volcando estructura para tabla eventos.usuarios
CREATE TABLE IF NOT EXISTS `usuarios` (
  `Id_usuario` int NOT NULL AUTO_INCREMENT,
  `Username` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `Id_Persona` int NOT NULL,
  `Id_tipo_usuario` int NOT NULL,
  PRIMARY KEY (`Id_usuario`),
  KEY `FK_Usuarios_Id_Persona` (`Id_Persona`),
  KEY `FK_Usuarios_Id_Tipo_Usuarios` (`Id_tipo_usuario`),
  CONSTRAINT `FK_Usuarios_Id_Persona` FOREIGN KEY (`Id_Persona`) REFERENCES `personas` (`Id_persona`),
  CONSTRAINT `FK_Usuarios_Id_Tipo_Usuarios` FOREIGN KEY (`Id_tipo_usuario`) REFERENCES `tipos_usuarios` (`Id_tipo_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb3;

-- Volcando datos para la tabla eventos.usuarios: ~17 rows (aproximadamente)
INSERT INTO `usuarios` (`Id_usuario`, `Username`, `Password`, `Id_Persona`, `Id_tipo_usuario`) VALUES
	(1, 'test@test.es', '', 1, 1),
	(2, 'usuario1', 'clave123', 2, 2),
	(3, 'usuario2', 'secreto', 3, 2),
	(13, 'castro', '$2y$10$/IXSP7an2UMWea7Xsd4REekT2uc1Ch8QBCWoT4dyyF2uFT9m59jTy', 21, 1),
	(14, 'castro', '$2y$10$omajsq17zeZHg10l.NVExua0n..7VGYPIXCUvjVfTYKBSiQKKid5e', 22, 1),
	(15, 'castro', '$2y$10$IhoFwWyMLAbOJqzn5nqyIulBLuI5v4l.61pHI/QBPrf/70Hv.mqRO', 23, 1),
	(16, 'PepElDelPalots', '$2y$10$GgchzvOaS2QEvTRv0CuLuuMy/.c9pTvoYvtV2rHEyXrfNT/MuziBG', 24, 1),
	(20, 'Usuario1@mail.com', 'pass123', 24, 1),
	(21, 'paco@mail.com', '$2y$10$/662U3UfYKlhA/oEHEc/1Oop1dRGiRNV1QtxBfgiJeaaqPtNF55um', 26, 1),
	(22, 'pepe@mail.com', '$2y$10$/ohOdiQsYRmYnJM6NlduH.8K6nxF9fI45pl8PIEkDwcN.3G8oL9AK', 24, 1),
	(23, 'prueba1@mail.com', '$2y$10$o3IMo6sjbOSXPCg1FxvTPe7mvMf84oybC24.I5YfqSXia8I/SCIoq', 29, 1),
	(24, 'prueba2@mail.com', '$2y$10$hCFC7nZW0VDbu.SkYLIC5uun.K7pdcbzGo8XufZxGCOa1RUBQulMC', 30, 1),
	(25, 'Prueba3@mail.com', '$2y$10$cxntd47FVGZCnC5QuQbMPOfHeEedjs0h6aRdAgWY1l4MaXc9tVu9i', 31, 3),
	(26, 'prueba4@mail.com', '$2y$10$TmNzoP3MLRLcFMGjswUENeLWXzk/Uz1DY8tTgb5K3BvkUPRifpE1O', 32, 3),
	(27, 'prueba5@mail.com', '$2y$10$B721ZshKqNQmlha52t07s.JjQO0sqDQ9LLSbkpA1uzg2Gx5uIpp36', 34, 3),
	(28, 'prueba6@mail.com', '$2y$10$XovPcx7CJWfeusDsVhjwie/mZS7BFzat/2nhbsmiRVihJfrkUD8Em', 36, 1),
	(30, 'admin@admin.com', '$2y$10$LEtTxxxBdn.0rlGZZOizmOMTkxXlqu0vNNOo4xlpr0ZHQBoBHeTHS', 38, 1),
	(31, 'lucia@lucia.com', '$2y$10$F3.wGQ9YivynhKtruvbI/OuVD/ZeNAp6S5J2jWUztVwzX.oR/IZS6', 39, 3),
	(32, 'paca@paca.com', '$2y$10$iGsacbTCDmI2nJwa224f6eTlFH2L7n68w705CPPKH64YgAVS87UdS', 40, 1),
	(33, 'pruebas1@pruebas1.com', '$2y$10$sHnvLVkHNmFuOgil/4mOHeH5TWqQ102fjujD.JIrlMp1MUqPXD/Ty', 41, 3);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
